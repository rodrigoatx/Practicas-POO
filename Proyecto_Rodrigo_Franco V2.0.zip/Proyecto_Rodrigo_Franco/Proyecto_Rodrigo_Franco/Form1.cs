﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Proyecto_Rodrigo_Franco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cargarCartas();
            inicializarJugadores();
            mostrarManos();
            decidirTurno();

            label_vida1.Text = "";
            label_vida2.Text = "";
            label_vida1.Text = "Vida " + jugador1.Vida;
            label_vida2.Text = "Vida " + jugador2.Vida;
        }
        List<Carta> todasLasCartas = new List<Carta>();
        Jugador jugador1 = new Jugador();
        Jugador jugador2 = new Jugador();
        Random random = new Random();
        int turno = 1; // 1 = jugador1 ataca, 2 = jugador2 ataca
        void cargarCartas()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            openFileDialog.Title = "Selecciona el archivo de cartas";

            if (openFileDialog.ShowDialog() == DialogResult.OK) // <-- Mostrar y verificar
            {
                string[] lineas = File.ReadAllLines(openFileDialog.FileName);

                foreach (string linea in lineas)
                {
                    string[] datos = linea.Split(',');
                    Carta c = new Carta(datos[0], int.Parse(datos[1]), int.Parse(datos[2]), datos[3]);
                    todasLasCartas.Add(c);
                }
            }
        }


        void inicializarJugadores()
        {
            for (int i = 0; i < 20; i++)
            {
                int indice = random.Next(todasLasCartas.Count);
                jugador1.Mazo.Add(todasLasCartas[indice]);
                int indice2 = random.Next(todasLasCartas.Count);
                jugador2.Mazo.Add(todasLasCartas[indice2]);
            }
            for (int i = 0; i < 5; i++)
            {
                jugador1.RobarCarta();
                jugador2.RobarCarta();
            }

        }

        void decidirTurno()
        {
            turno = random.Next(1, 3);
            MessageBox.Show("El jugador " + turno + " comienza el juego, por lo tanto el jugador " + turno + " Es el atacante ");
            if (turno == 1)
            {
                Label_jugacor1.Text = "Jugador 1: Atactante ";
                Label_jugacor2.Text = "Jugador 2: Defensor ";

            }
            else if (turno ==2)
            {
                Label_jugacor1.Text = "Jugador 1: Defensor ";
                Label_jugacor2.Text = "Jugador 2: Atactante ";
            }
        }

        void mostrarManos()
        {
            listBoxJugador1.Items.Clear();
            listBoxJugador2.Items.Clear();
            foreach (var c in jugador1.Mano)
            {
                listBoxJugador1.Items.Add(c.Nombre + " A:" + c.Ataque + " D:" + c.Defensa + " E:" + c.Elemento);
            }
            foreach (var c in jugador2.Mano)
            {
                listBoxJugador2.Items.Add(c.Nombre + " A:" + c.Ataque + " D:" + c.Defensa + " E:" + c.Elemento);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (turno == 1)
            {
                atacar(jugador1, jugador2, listBoxJugador1, listBoxJugador2);
                //turno = 2;
            }
            else if (turno == 2)
            {
                atacar(jugador2, jugador1, listBoxJugador2, listBoxJugador1);
                //turno = 1;
            }
            mostrarManos();
            verificarGanador();
            label_vida1.Text = "";
            label_vida2.Text = "";
            label_vida1.Text = "Vida " + jugador1.Vida;
            label_vida2.Text = "Vida " + jugador2.Vida;
        }
        void atacar(Jugador atacante, Jugador defensor, ListBox manoAtacante, ListBox manoDefensor)
        {
            if (manoAtacante.SelectedIndex == -1 || manoDefensor.SelectedIndex == -1)
            {
                MessageBox.Show("Selecciona las cartas de ataque y defensa.");
                return;
            }


            Carta cartaAtacante = atacante.Mano[manoAtacante.SelectedIndex];
            Carta cartaDefensor = defensor.Mano[manoDefensor.SelectedIndex];
            aplicarElementos(cartaAtacante, cartaDefensor);

            if (cartaAtacante.Ataque > cartaDefensor.Defensa)
            {
                defensor.Vida--;
                MessageBox.Show("¡El ataque fue exitoso! El defensor pierde 1 vida.");
            }

            
            MessageBox.Show("Atacante " + cartaAtacante.Nombre + " de elemento " + cartaAtacante.Elemento + " ataque " + cartaAtacante.Ataque + "\n" +
                "Defensor " + cartaDefensor.Nombre + " elemento " + cartaDefensor.Elemento + " defensa " + cartaDefensor.Defensa + "\n"
                );

            atacante.Mano.Remove(cartaAtacante);
            defensor.Mano.Remove(cartaDefensor);

            atacante.RobarCarta();
            defensor.RobarCarta();
            decidirTurno();

        }
        void aplicarElementos(Carta atacante, Carta defensor)
        {
            if ((atacante.Elemento == "Hielo" && defensor.Elemento == "Fuego") ||
                (atacante.Elemento == "Fuego" && defensor.Elemento == "Tierra") ||
                (atacante.Elemento == "Tierra" && defensor.Elemento == "Electricidad") ||
                (atacante.Elemento == "Electricidad" && defensor.Elemento == "Hielo"))
            {
                atacante.Ataque *= 2;

            }
            else if ((defensor.Elemento == "Hielo" && atacante.Elemento == "Fuego") ||
                (defensor.Elemento == "Fuego" && atacante.Elemento == "Tierra") ||
                (defensor.Elemento == "Tierra" && atacante.Elemento == "Electricidad") ||
                (defensor.Elemento == "Electricidad" && atacante.Elemento == "Hielo"))
            {
                defensor.Defensa *= 2;
            }

        }

        void verificarGanador()
        {
            if (jugador1.Vida <= 0)
            {
                MessageBox.Show("¡Jugador 2 gana!");
                Application.Exit();
            }
            else if (jugador2.Vida <= 0)
            {
                MessageBox.Show("¡Jugador 1 gana!");
                Application.Exit();
            }
        }
    }
}
public class Carta
{
    public string Nombre;
    public int Ataque;
    public int Defensa;
    public string Elemento;

    public Carta(string nombre, int ataque, int defensa, string elemento)
    {
        Nombre = nombre;
        Ataque = ataque;
        Defensa = defensa;
        Elemento = elemento;
    }
   
}

public class Jugador
{
    public int Vida = 3;
    public List<Carta> Mazo = new List<Carta>();
    public List<Carta> Mano = new List<Carta>();

    public void RobarCarta()
    {
        if (Mazo.Count > 0)
        {
            Random r = new Random();
            int indice = r.Next(Mazo.Count);
            Mano.Add(Mazo[indice]);
            Mazo.RemoveAt(indice);
        }
        else
        {

        }
    }
}

