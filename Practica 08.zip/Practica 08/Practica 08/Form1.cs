﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Practica_08
{
    public partial class Form1 : Form
    {
        List<Pedido> pedidos;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pedidos = new List<Pedido>();
            StreamReader reader = new StreamReader("Entregas.dat");
            while (!reader.EndOfStream) {
                string[] lineas = reader.ReadLine().Split('|');
                string clave = lineas[0];
                string estatus = lineas[1];
                string repartidor = lineas[2];

                comboClave.Items.Add(clave);

                Pedido p = new Pedido(clave, estatus, repartidor);
                pedidos.Add(p);
            }
            reader.Close();
        }

        private void comboClave_SelectedIndexChanged(object sender, EventArgs e)
        {
            string clave = comboClave.Text;

            foreach (var item in pedidos)
            {
                if (item.clave == clave)
                {
                    textoRepartidor.Text = item.repartidor;
                    comboEstatus.SelectedItem = item.estatus;
                }
            }
        }

        private void comboEstatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboEstatus.Text == "Preparando"|| comboEstatus.Text == "Horneando")
            {
                textoRepartidor.Enabled = false;
            }
            else
            {
                textoRepartidor.Enabled=true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var item in pedidos)
            {
                if (item.clave == comboClave.Text)
                {
                    item.repartidor = textoRepartidor.Text;
                    item.estatus = comboEstatus.Text;
                }
            }

            StreamWriter writer = new StreamWriter("Entregas.dat",false);
            foreach (var item in pedidos)
            {
                writer.WriteLine(item.clave + "|" + item.estatus + "|" + item.repartidor);
            }
            writer.Close();
            MessageBox.Show("Actualizado");
        }
    }
}
