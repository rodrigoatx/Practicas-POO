﻿namespace Practica_08
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboClave = new System.Windows.Forms.ComboBox();
            this.comboEstatus = new System.Windows.Forms.ComboBox();
            this.textoRepartidor = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clave del pedido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Estatus del pedido";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Repartidor";
            // 
            // comboClave
            // 
            this.comboClave.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboClave.FormattingEnabled = true;
            this.comboClave.Location = new System.Drawing.Point(150, 13);
            this.comboClave.Name = "comboClave";
            this.comboClave.Size = new System.Drawing.Size(121, 21);
            this.comboClave.TabIndex = 3;
            this.comboClave.SelectedIndexChanged += new System.EventHandler(this.comboClave_SelectedIndexChanged);
            // 
            // comboEstatus
            // 
            this.comboEstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboEstatus.FormattingEnabled = true;
            this.comboEstatus.Items.AddRange(new object[] {
            "Preparando",
            "Horneando",
            "Entregando"});
            this.comboEstatus.Location = new System.Drawing.Point(150, 48);
            this.comboEstatus.Name = "comboEstatus";
            this.comboEstatus.Size = new System.Drawing.Size(121, 21);
            this.comboEstatus.TabIndex = 4;
            this.comboEstatus.SelectedIndexChanged += new System.EventHandler(this.comboEstatus_SelectedIndexChanged);
            // 
            // textoRepartidor
            // 
            this.textoRepartidor.Enabled = false;
            this.textoRepartidor.Location = new System.Drawing.Point(150, 85);
            this.textoRepartidor.Name = "textoRepartidor";
            this.textoRepartidor.Size = new System.Drawing.Size(206, 20);
            this.textoRepartidor.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(281, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Actualizar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 177);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textoRepartidor);
            this.Controls.Add(this.comboEstatus);
            this.Controls.Add(this.comboClave);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Pizzeria";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboClave;
        private System.Windows.Forms.ComboBox comboEstatus;
        private System.Windows.Forms.TextBox textoRepartidor;
        private System.Windows.Forms.Button button1;
    }
}

