﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_08
{
    internal class Pedido
    {
        public string clave, estatus, repartidor;

        public Pedido(string clave, string estatus, string repartidor)
        {
            this.clave = clave;
            this.estatus = estatus;
            this.repartidor = repartidor;
        }
    }
}
