﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRR
{
    abstract class Medio
    {
        public string nombre;
        public int año;
        public string genero;

        public Medio(string nombre, int año, string genero)
        {
            this.nombre = nombre;
            this.año = año;
            this.genero = genero;
        }

        public abstract string mostrarDescripcion();
    }
}
