﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRR
{
    public partial class Canciones: Form
    {
        public Form1 principal;
        List<string> generos;
        Dictionary<int, Cancion> canciones;
        int contador = 0;

        public Canciones()
        {
            InitializeComponent();
            generos = new List<string>();
            canciones = new Dictionary<int, Cancion>();
        }

        private void Canciones_Load(object sender, EventArgs e)
        {
            StreamReader reader = new StreamReader("canciones.txt");

            while (!reader.EndOfStream)
            {
                string[] lines = reader.ReadLine().Split(',');
                string genero = lines[3];

                if (!generos.Contains(genero))
                {
                    generos.Add(genero);
                    comboGenero.Items.Add(genero);
                }
            }
            reader.Close();
        }

        private void Canciones_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        void agregar(Cancion c)
        {
            StreamWriter writer = new StreamWriter("canciones.txt", true);
            writer.WriteLine(c.artista + "," + c.nombre + "," + c.año + "," + c.genero);
            writer.Close();
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            string artista = textArtista.Text;
            string nombre = textNombre.Text;
            int año = int.Parse(textAño.Text);
            string genero = comboGenero.Text;
            bool existe = false;

            if (artista.Length == 0)
            {
                MessageBox.Show("El artista no puede estar vacio");
            }
            else if (nombre.Length == 0)
            {
                MessageBox.Show("El nombre no puede estar vacio");
            }
            else if (año <= 0 || año > 2019)
            {
                MessageBox.Show("El año no puede ser menor a 0 o mayor a 2019");
            }
            else
            {
                StreamReader reader = new StreamReader("canciones.txt");
                while (!reader.EndOfStream)
                {
                    string[] lines = reader.ReadLine().Split(',');
                    string nombreCancion = lines[1];

                    if (nombreCancion == nombre)
                    {
                        existe = true;
                    }
                }

                reader.Close();

                if (existe)
                {
                    MessageBox.Show("La cancion ya existe");
                }
                else
                {
                    Cancion c = new Cancion(nombre, año, genero, artista);
                    canciones.Add(contador, c);
                    contador++;
                    Task.Factory.StartNew(() => agregar(c));
                    this.Hide();
                    principal.Show();
                }
            }
        }
    }
}
