﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;    

namespace RRR
{
    public partial class Peliculas: Form
    {
        public Form1 principal;
        List<string> generos;
        Dictionary<int, Pelicula> peliculas;
        int contador = 0;

        public Peliculas()
        {
            InitializeComponent();
            generos = new List<string>();
            peliculas = new Dictionary<int, Pelicula>();
        }

        private void Peliculas_Load(object sender, EventArgs e)
        {
            StreamReader reader = new StreamReader("peliculas.txt");

            while (!reader.EndOfStream)
            {
                string[] lines = reader.ReadLine().Split(',');
                string genero = lines[2];

                if(!generos.Contains(genero))
                {
                    generos.Add(genero);
                    comboGenero.Items.Add(genero);
                }
            }

            reader.Close();
        }

        private void Peliculas_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        void agregar(Pelicula p)
        {
            StreamWriter writer = new StreamWriter("peliculas.txt", true);
            writer.WriteLine(p.nombre + "," + p.año + "," + p.genero + "," + p.calificacion);
            writer.Close();
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            string nombre = textNombre.Text;
            string genero = comboGenero.Text;
            int año = int.Parse(textAño.Text);
            int calificacion = int.Parse(textCalificacion.Text);

            if (nombre.Length == 0)
            {
                MessageBox.Show("El nombre no puede estar vacio");
            }
            else if(calificacion < 1 || calificacion > 10)
            {
                MessageBox.Show("La calificacion debe ser entre 1 y 10");
            }
            else if (año < 1900 || año > 2019)
            {
                MessageBox.Show("El año debe ser entre 1900 y 2019");
            }
            else
            {
                Pelicula p = new Pelicula(nombre, año, genero, calificacion);
                peliculas.Add(contador, p);
                Task.Factory.StartNew(() => agregar(p));
                contador++;
                this.Hide();
                principal.Show();
            }
        }
    }
}
