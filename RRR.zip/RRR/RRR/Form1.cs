﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRR
{
    public partial class Form1: Form
    {
        Canciones c;
        Peliculas p;
        public Form1()
        {
            InitializeComponent();
            c = new Canciones(); 
            p = new Peliculas();
            c.principal = this;
            p.principal = this;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonCanciones_Click(object sender, EventArgs e)
        {
            this.Hide();
            c.Show();
        }

        private void buttonPeliculas_Click(object sender, EventArgs e)
        {
            this.Hide();
            p.Show();
        }
    }
}
