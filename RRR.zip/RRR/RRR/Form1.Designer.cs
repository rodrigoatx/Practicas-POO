﻿namespace RRR
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCanciones = new System.Windows.Forms.Button();
            this.buttonPeliculas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCanciones
            // 
            this.buttonCanciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCanciones.Location = new System.Drawing.Point(12, 12);
            this.buttonCanciones.Name = "buttonCanciones";
            this.buttonCanciones.Size = new System.Drawing.Size(190, 113);
            this.buttonCanciones.TabIndex = 0;
            this.buttonCanciones.Text = "Dar de alta canciones";
            this.buttonCanciones.UseVisualStyleBackColor = true;
            this.buttonCanciones.Click += new System.EventHandler(this.buttonCanciones_Click);
            // 
            // buttonPeliculas
            // 
            this.buttonPeliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPeliculas.Location = new System.Drawing.Point(12, 131);
            this.buttonPeliculas.Name = "buttonPeliculas";
            this.buttonPeliculas.Size = new System.Drawing.Size(190, 110);
            this.buttonPeliculas.TabIndex = 1;
            this.buttonPeliculas.Text = "Dar de alta peliculas";
            this.buttonPeliculas.UseVisualStyleBackColor = true;
            this.buttonPeliculas.Click += new System.EventHandler(this.buttonPeliculas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 251);
            this.Controls.Add(this.buttonPeliculas);
            this.Controls.Add(this.buttonCanciones);
            this.Name = "Form1";
            this.Text = "Alta";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonCanciones;
        private System.Windows.Forms.Button buttonPeliculas;
    }
}

