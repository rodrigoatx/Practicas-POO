﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RRR
{
    class Pelicula : Medio
    {
        public int calificacion;

        public Pelicula(string nombre, int año, string genero, int calificacion) : base(nombre, año, genero)
        {
            this.calificacion = calificacion;
        }

        public override string mostrarDescripcion()
        {
            return nombre + " " + año + " " + genero + " " + calificacion;
        }
    }
}
