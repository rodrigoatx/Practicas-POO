﻿namespace Proyecto_Rodrigo_Franco
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxJugador1 = new System.Windows.Forms.ListBox();
            this.listBoxJugador2 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Label_jugacor1 = new System.Windows.Forms.Label();
            this.Label_jugacor2 = new System.Windows.Forms.Label();
            this.label_vida2 = new System.Windows.Forms.Label();
            this.label_vida1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxJugador1
            // 
            this.listBoxJugador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxJugador1.FormattingEnabled = true;
            this.listBoxJugador1.ItemHeight = 29;
            this.listBoxJugador1.Location = new System.Drawing.Point(15, 12);
            this.listBoxJugador1.Name = "listBoxJugador1";
            this.listBoxJugador1.Size = new System.Drawing.Size(481, 91);
            this.listBoxJugador1.TabIndex = 0;
            // 
            // listBoxJugador2
            // 
            this.listBoxJugador2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxJugador2.FormattingEnabled = true;
            this.listBoxJugador2.ItemHeight = 29;
            this.listBoxJugador2.Location = new System.Drawing.Point(15, 173);
            this.listBoxJugador2.Name = "listBoxJugador2";
            this.listBoxJugador2.Size = new System.Drawing.Size(481, 91);
            this.listBoxJugador2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(507, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 64);
            this.button1.TabIndex = 2;
            this.button1.Text = "Atacar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Label_jugacor1
            // 
            this.Label_jugacor1.AutoSize = true;
            this.Label_jugacor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_jugacor1.Location = new System.Drawing.Point(498, 12);
            this.Label_jugacor1.Name = "Label_jugacor1";
            this.Label_jugacor1.Size = new System.Drawing.Size(108, 25);
            this.Label_jugacor1.TabIndex = 3;
            this.Label_jugacor1.Text = "Jugador 1";
            // 
            // Label_jugacor2
            // 
            this.Label_jugacor2.AutoSize = true;
            this.Label_jugacor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_jugacor2.Location = new System.Drawing.Point(502, 173);
            this.Label_jugacor2.Name = "Label_jugacor2";
            this.Label_jugacor2.Size = new System.Drawing.Size(108, 25);
            this.Label_jugacor2.TabIndex = 4;
            this.Label_jugacor2.Text = "Jugador 2";
            // 
            // label_vida2
            // 
            this.label_vida2.AutoSize = true;
            this.label_vida2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_vida2.Location = new System.Drawing.Point(502, 211);
            this.label_vida2.Name = "label_vida2";
            this.label_vida2.Size = new System.Drawing.Size(79, 25);
            this.label_vida2.TabIndex = 5;
            this.label_vida2.Text = "Vida: 3";
            // 
            // label_vida1
            // 
            this.label_vida1.AutoSize = true;
            this.label_vida1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_vida1.Location = new System.Drawing.Point(502, 46);
            this.label_vida1.Name = "label_vida1";
            this.label_vida1.Size = new System.Drawing.Size(79, 25);
            this.label_vida1.TabIndex = 6;
            this.label_vida1.Text = "Vida: 3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 314);
            this.Controls.Add(this.label_vida1);
            this.Controls.Add(this.label_vida2);
            this.Controls.Add(this.Label_jugacor2);
            this.Controls.Add(this.Label_jugacor1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBoxJugador2);
            this.Controls.Add(this.listBoxJugador1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxJugador1;
        private System.Windows.Forms.ListBox listBoxJugador2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Label_jugacor1;
        private System.Windows.Forms.Label Label_jugacor2;
        private System.Windows.Forms.Label label_vida2;
        private System.Windows.Forms.Label label_vida1;
    }
}

